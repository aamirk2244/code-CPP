#include <iostream>
#include <string>
#include <windows.h>
#include <conio.h>
#define SIZE 100

class Stack{
	int l;
	int s[SIZE];
public:
	Stack();
	void push(int val);
	int pop();
	bool is_full();
	bool is_empty();
	void Check_Bracket(std::string b);
};
Stack::Stack()
{
	l = -1;
	
}

bool Stack::is_full()
{
	if(l+1 == SIZE)
		return true;
		
	return false;
}
bool Stack::is_empty()
{
	if(l == -1)
		return true;
	
	return false;
	
}
void Stack::push(int val)
{
	if(is_full())
		throw "Stack Overflow";
	
	s[++l]  = val; 
	
}
int Stack::pop()
{
	if(is_empty())
		throw "Stack Underflow";
		
	return s[l--];
	
}
//

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE); // For use of SetConsoleTextAttribute()

void Stack::Check_Bracket(std::string b)
{
	int c;
	for(int i  =0; i < b.length(); i++)
	{
		if(is_empty() && b[i] == 41)
		{
			std::cout << "Please remove the highlighted One " << std::endl;
		 int y=240; // 240 = white background, black foreground 

    int len ;
	std::string text = b;
    len = text.length();
    int count = 0;
    std::cout <<std::endl << "\t\t"; // start 3 down, 2 tabs, right
     // set color for the next print
	for(int i = 0 ; i < len; i++)
    {
    	if(b[i] ==41 && count == 0)
    	{
    		 SetConsoleTextAttribute(console, 240);
    		std::cout << b[i];
    		count++;
		}
		else{
				 SetConsoleTextAttribute(console,15);
				std::cout << b[i];
		}
	}
	return;
	}
		if(b[i] == 40)
			push(b[i]);
		
		else if(b[i] == 41 && !is_empty())
			pop();
	}
	if(is_empty())
		std::cout << "there is no Problem in your Expression " << std::endl;
	else
	{
		c = pop();
		std::cout << "Please remove the highlighted One " << std::endl;
		 int y=240; // 240 = white background, black foreground 

    int len ;
	std::string text = b;
    len = text.length();
    std::cout <<std::endl << "\t\t"; // start 3 down, 2 tabs, right
     // set color for the next print
    int count = 0;
	for(int i = 0 ; i < len; i++)
    {
    	if(b[i] == c && count == 0)
    	{
    		 SetConsoleTextAttribute(console, 240);
    		std::cout << b[i];
    		count++;
		}
		else{
				 SetConsoleTextAttribute(console, 15);
				std::cout << b[i];
		}
	}
 
    SetConsoleTextAttribute(console, 15); // set color to black background, white chars
     // Program over, wait for a keypress to close program
   
	}
		
}
int main()
{

     
	Stack s;
//	std::string exp = " ( (((((((( ))))))))())()";
//	std::string exp = "( ((()))() (2 *3 )() )";
	std::string exp = " (()()";
	
	try{
		s.Check_Bracket(exp);
		
	}catch(const char* msg){
		std::cout << msg << std::endl;
	}
}

#include<iostream>
#define maxSize 5
class node{
public:
	node* next;
	int val;
	node(int val);
};
node::node(int val)
{
	next = NULL;
	this->val = val;
}
class Queue{
	node *front, *rear;
	int len;
public:
	Queue();
	void free(node* &del);
	void enqueue(int val);
	bool is_empty();
	int dequeue();
	bool is_full();
};

Queue::Queue()
{
	front = rear = NULL;
	len = 0;
}
bool Queue::is_empty()
{
	if(front == NULL)
		return true;
	return false;
}
void Queue::free(node* &del)
{
	del->next = NULL;
	delete del;
	del = NULL;
}
bool Queue::is_full()
{
	if(len == maxSize)
		return true;
	return false;
}
void Queue::enqueue(int val) 
{
	if(is_full())
		throw "Queue overflow";
		
	node *n = new node(val);
	if(front == NULL)
	{
		front = n;
		rear = front;
		len++;
		return;
	}
	rear->next = n;
	rear = rear->next;
	len++;
	
}
int Queue::dequeue()
{
	if(is_empty())
		throw "Queue Underflow";
	node *del = front;
	int ret = del->val;
	front = front->next;
	free(del);
	return ret;
}
int main()
{
	Queue q;
	try{
			q.enqueue(1);
	q.enqueue(2);
	q.enqueue(3);
	q.enqueue(4);
	q.enqueue(5);
	
	std::cout << q.dequeue() << std::endl;	
	std::cout << q.dequeue() << std::endl;	
	std::cout << q.dequeue() << std::endl;	
	std::cout << q.dequeue() << std::endl;	
	std::cout << q.dequeue() << std::endl;	
	std::cout << q.dequeue() << std::endl;	
	
	}catch(const char* msg)
	{
		std::cout << msg << std::endl;
	}

}

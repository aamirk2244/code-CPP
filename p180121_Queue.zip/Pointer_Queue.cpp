#include<iostream>
class Queue{
	int in , out, SIZE;
	int *q;
	bool is_full, is_empty;
public:
	Queue();
	void inc(int &n);
	void enqueue(int val);
	int dequeue();
};
void Queue::inc(int &n)
{
	if(n+1 == SIZE)
	{
		n = 0;
		return;
	}
	n++;
}
Queue::Queue()
{
	std::cout << "Enter Size of your Queue" << std::endl;
	std::cin >> SIZE;
	q = new int[SIZE];
	this->SIZE = SIZE;
	in = out = 0;
	is_full = false;
	is_empty = true;
	
}
void Queue::enqueue(int val)
{
	if(is_full)
		throw "Queue Overflow";
	q[in] = val;
	std::cout << q[in ] << " enqueued " << std::endl;

	inc(in); 
	is_empty = false;
	if(in == out)
	{
		is_full = true;
		is_empty = false;
	}
}
int Queue::dequeue()
{
	if(is_empty)
		throw "Queue Underflow" ;
	int val = q[out];
	inc(out);
	is_full = false;
	if(out == in)
	{
		is_empty = true;
		is_full = false;
		in = out = 0;	
	}	
	
	return val;
}
int main()
{
	
	Queue q;
	try{
	q.enqueue(1);
	q.enqueue(2);
		
	std::cout << q.dequeue() << " dequeued " << std::endl;
	q.enqueue(99);
	std::cout << q.dequeue() << " dequeued " << std::endl;
	std::cout << q.dequeue() << " dequeued " << std::endl;
	
	}catch(const char* msg){
		std::cout << msg << std::endl;
	}
	return 0;
	
}

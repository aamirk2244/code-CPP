#include<iostream>
#define SIZE 20
class Queue{
	int q[SIZE];
	int in , out;
	int is_full, is_empty;
public:
	void enqueue(int val);
	
	Queue();
	int dequeue();
	void inc(int &i);
	void Railway(int *train);
	int top();
};

Queue::Queue()
{
	in  = out = 0;
	is_full = false;
	is_empty = true;
	
}
void Queue::Railway(int *train)
{
	Queue H[3];
	int len =  9;
	int* order = new int[len];
	int o = len-1;
	int max = 9;
	int check = 1;
	int count = 0;
	int insert = 0;
	for(int h = 0 ; h < len; h++)
	{
		for(int hh = 0 ; hh < len; hh++)
		{
			if(train[hh] == check && check <= max-6)
			{
				H[insert].enqueue(train[hh]);
				check++;
			}
			else if(train[hh] == check && check >max-6 && check <= max-3)
			{
				H[insert+1].enqueue(train[hh]);
				check++;
			}
			
			else if(train[hh] == check && check >max-3 && check <= max)
			{
				H[insert+2].enqueue(train[hh]);
				check++;
			}
		}
		
	}
	int incr = 0;
	while(true)
	{
		if(H[0].is_empty && H[1].is_empty && H[2].is_empty)
			break;
		while(!H[incr].is_empty)
		{
			order[o] = H[incr].dequeue();
			o--;
		}
		incr++;
		while(!H[incr].is_empty)
		{
			order[o] = H[incr].dequeue();
			o--;
		}
		incr++;
		while(!H[incr].is_empty)
		{
			order[o] = H[incr].dequeue();
			o--;
		}
	}
	std::cout << "Came to new world . Congrats " << std::endl;
	system("color 30");
	std::cout << "Our ordered Train " << std::endl;
	std::cout << "[ " ;
	for(int j = 0 ; j < len; j++)
	{
		std::cout << order[j] << " ";
	}
	std::cout << "]" << std::endl;
}
void Queue::inc(int &i)
{
	if(i+1 == SIZE)	// circular increment
		i = 0;
	else
		i++;
}
int Queue::top()
{
	if(is_empty)
		return -1;
	return q[in];
}
void Queue::enqueue(int val)
{
	if(is_full)
		throw "Queue Overflow" ;
	
	q[in] = val;
	
	is_empty = false;
	inc(in);
	if(in == out)
	{
		is_full = true;
		is_empty = false;
	}
		
}
int Queue::dequeue()
{
	if(is_empty)
		throw "Queue Underflow";
	
	int val = q[out];
	is_full = false;
	inc(out);
	if(in == out)
		is_empty = true;
		
	return val;
}
int main()
{
	Queue q;
	int train[9] = {5,8,1,7,4,2,9,6,3};
try{
	q.Railway(train);
}catch(const char* msg){
	std::cout << msg << std::endl;
	
}
return 0;
	
}

#include<iostream>
#include<windows.h>
#define SIZE 20
class Stack{
	int q[SIZE];
	int in;
public:
	bool is_full, is_empty;

	Stack();
	void push(int val);
	int pop();
	int top();	
};
Stack::Stack()
{
	in = -1;
	is_full = false;is_empty = true;
}
void Stack::push(int val)
{
	if(is_full)
		throw "Stack Overflow";
	q[++in] = val;
	is_empty = is_full = false;
	if(in+1 == SIZE)
	{
		is_full = true;
	}
}
int Stack::pop()
{
	
	if(is_empty)
		throw "Stack Underflow";
	
	is_full = is_empty = false;	
	int ret = q[in--];
	if(in == -1)
	{
		is_empty = true;is_full = false;
	}
	return ret;
}
int Stack::top()
{
	if(in < 0 || in >= SIZE)
	{
		return -1;		// special case for Train
	}
	return q[in];
}
void gotoxy(int x_axis, int y_axis)
{
	
	COORD axis;
	axis.X = x_axis;
	axis.Y = y_axis;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),axis);

}
void Move_Train(int *t)
{
	int inc = 0;
	int x_axis, y_axis;
x_axis = 0;
 y_axis = 7;
	while(true)
	{
		inc++;
		x_axis += 1;
		y_axis =  7;
		
		gotoxy(x_axis, y_axis);
		
		Sleep(30);
		std::cout << "Beeeeeeeeep --> [ ";	
		for(int i = 0  ; i < 9; i++)
		{
			std::cout << t[i] << " ";
		}
		std::cout << " ] -->";
		system("cls");
		if(inc == 150){
		std::cout << "Beeeeeeeeep --> [ ";	
		
		for(int i = 0  ; i < 9; i++)
		{
			std::cout << t[i] << " ";
		}std::cout << " ] --->  ";
		
		
				break;
		}
	}
	std::cout << std::endl;
	std::cout <<" Station Reached " << std::endl;
}
void Train(Stack &H1, Stack &H2, Stack &H3)
{
	Stack H[3]  = {H1, H2, H3};
	
	int train[] = {5,8,1,7,4,2,9,6,3};
	int len = sizeof(train)/sizeof(int);
	int min = 1;
	int max = 9;
	int *order = new int[len];
	int j = len-1;
	int cc = 0;
	int i = len-1;
	int br = 0;
	for(i = len-1; i >= 0; i--)
	{	
		for(int l = 0 ; l < 3 ; l++)
		{
			if(H[l].is_empty)
			{
				H[l].push(train[i]);
				std::cout <<  " BOX  " << train[i] << " --> is pushed in holding " << l+1 << std::endl;
				i--;
			}	
		}
		for(int k = 0 ; k < 3; k++ )
		{
			for(int m =  0; m < 3; m++)
			{
				if( !(H[m].is_empty)  && H[m].top() == min)
				{
					order[j] = H[m].pop();
					j--;
					min++;
				}
			}
		}
		int check = train[i];
		while(check != (max+1))	// maximum element is 10
		{	// if closed found then insert on top of it 
			if(i == -1 || j == -1){
				 break;
			}
			for(int m = 0 ; m < 3; m++)
			{
				if( !(H[m].is_empty) && check == H[m].top())
				{
					if(i == -1)
						break;
					H[m].push(train[i]);
					
					std::cout <<  " BOX  " <<  train[i] << " --> is pushed in holding " << m+1 << std::endl;
					
					for(int t = 0 ; t < 6; t++ )
					{			
						for(int p = 0 ; p < 3; p++)
						{
							if( !(H[p].is_empty)  && H[p].top() == min)
							{
							 
								order[j] = H[p].pop();
								std::cout <<  " BOX  " << order[j] << " <-- is popped from holding " << p+1 << std::endl;
								j--;
								min++;
							
								}
						}
					}
					i--;
					check = train[i];
					if(i == -1)break;
					for(int b= 0 ; b < 3; b++)
					{
						if(H[b].is_empty)
						{
							H[b].push(train[i]);
							
							std::cout <<  " BOX  " << train[i] << " --> is pushed in holding " << m+1 << std::endl;
							
							break;
						}
					}
				}
					
			
			}
			
			check++;
		}
	}
	std::cout << "\tTrain is Redy to Go --> beeeeeeeeeeeeep ----> [ ";
	for(int i = 0; i < len; i++)
	{
		std::cout << order[i] << " ";
	}
	std::cout << " ] --->   All is Well"<< std::endl << std::endl;

std::cout << "Let's Go to Disney Land\nHave a Safe Journey " << std::endl;
std::cout << "Press any key To Move the Train " << std::endl;

std::cin.get();
Move_Train(order);

} 
int main()
{
	
	Stack H1, H2, H3;
try{
	
	Train(H1, H2, H3);
	
	}catch(const char* msg){
		std::cout << msg << std::endl;
	}
	return 0;
}

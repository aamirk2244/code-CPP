#include <iostream>
using namespace std;

class Array {
// think about the private data members...
int length;
int *array;
public:
// provide definitions of following functions...
Array(); // a default constructor
int size();
Array(int size); // a parameterized constructor initializing an Array of predefined size
Array(int *arr, int size); // initializes the Array with an existing Array
Array(const Array &); // copy constructor
int& operator[](int i); //returns the integer at index after checking the out of range error
int& operator[](int i)const;
void operator=(const Array& arr)
{
  
    for (int i = 0; i < arr.length; i++)
    {
        this->array[i] = arr.array[i];
    }
}
Array operator+(const Array&); //adds two Array
Array operator-(const Array&); //subtracts two Array
Array operator++(); //adds one to each element of Array
Array operator++(int); //adds one to each element of Array
Array& operator--(int); //subtracts one from each element of array
bool operator==(const Array& arr)
{
   for(int i =0; i < arr.length; i++)
    {
        if (this->array[i] != arr.array[i])
        {
            return false;
        }
    }
    return true;
}
  friend std::ostream& operator<<(std::ostream& os, const Array& arr) {
        for (int i = 0; i < arr.length; i++) {
            os << arr.array[i] << ' ';
        }
        return os;
    }

    // Overloaded input operator
    friend std::istream& operator>>(std::istream& is, Array& arr) {
        for (int i = 0; i < arr.length; i++) {
            is >> arr.array[i];
        }
        return is;
    }
bool operator!()
{
    if (this->length <= 0)
    {
        return true;
    }
    return false;
}

void operator+=(const Array&);
void operator-=(const Array&); //subtracts two Array
int operator()(int idx, int val)
{
    if (idx >= length || idx < 0){return -1;}
    if (this->array[idx] != val){return -1;}
    
    this->array[idx] = 0;
    int swap;
    for(int i = idx+1; i < length; i++ )
    {
        swap = this->array[i-1];
        this->array[i-1] = this->array[i];
        this->array[i] = swap;
    }
    return 1;
}
 // erases the value val at idx. Returns 1 for a successful //deletion and
// -1 if idx does not exists or is invalid. Shift the elements after idx to the //left.
// ~Array(); // destructor...
};
Array::Array()
{
    length = 0;
}

Array::Array(int size)
{
    array = new int(size);
    for (int i = 0; i < size; i++)
    {
        array[i] = 0;
    }
    length = size;
}

Array::Array(int *arr, int size)
{
    array = new int(size);
    for (int i= 0; i < size; i++)
    {
        array[i] = arr[i];
    }
    length = size;
}

Array::Array(const Array &copy)
{
    this->array = new int(copy.length);
    for(int i = 0 ; i < copy.length; i++)
    {
       this->array[i] = copy.array[i];
    }
    this->length = copy.length;
}

int Array::size()
{
    return length;
}
int& Array::operator[](int i) 
{
    if (i < 0 || i >= length)
    {
        throw std::out_of_range("Index out of bounds");
    }
    return array[i];
}

Array Array::operator+(const Array& copy)
{
    int array_length = copy.length;
    Array result(array_length);

    for(int i = 0 ; i < array_length; i++)
    {
        result[i] = copy.array[i] + this->array[i];
    }

    return result;
}

Array Array::operator-(const Array& copy)
{
    int array_length = copy.length;
    Array result(array_length);

    for(int i = 0 ; i < array_length; i++)
    {
        result[i] = this->array[i] - copy.array[i]; 
    }

    return result;
}

void Array::operator+=(const Array& copy)
{

     for(int i = 0 ; i < copy.length; i++)
    {
        this->array[i] = copy.array[i] + this->array[i];
    }

}

void Array::operator-=(const Array& copy)
{

     for(int i = 0 ; i < copy.length; i++)
    {
        this->array[i] =  this->array[i] -  copy.array[i];
    }

}

Array Array::operator++()
{
    for(int i = 0; i < length; i++)
    {
        array[i] += 1;
    }
    return *this;
}

Array Array::operator++(int)
{
   for(int i = 0; i < length; i++)
    {
        array[i] += 1;
    }
    return *this;
}

Array& Array::operator--(int)
{
   for(int i = 0; i < length; i++)
    {
        array[i] -= 1;
    }
    return *this;
}



ostream& operator<<(ostream& input, const Array&); //Inputs the Array
istream& operator>>(istream& ouput, Array&); //Outputs the Array

// int main()
// {
//     int values[3] = {1, 2, 3};
//     Array arr(values, 3);
  
// }

#include "Array.cpp"
// #include "BigInt.cpp"
// #include "Book.cpp"
#include <gtest/gtest.h>
// Q1: Array.cpp

TEST(ArrayTest, DefaultConstructor) {
    Array arr;
    EXPECT_EQ(arr.size(), 0);
}


TEST(ArrayTest, ParametrizedConstructor) {
    Array arr(5);
    EXPECT_EQ(arr.size(), 5);
}
TEST(ArrayTest, ParameterizedConstructor) {
  Array a(3);
  EXPECT_EQ(a[0], 0);
  EXPECT_EQ(a[1], 0);
  EXPECT_EQ(a[2], 0);
}

TEST(ArrayTest, ConstructorWithExistingArray) {
  int arr[3] = {1, 2, 3};
  Array a(arr, 3);
  EXPECT_EQ(a[0], 1);
  EXPECT_EQ(a[1], 2);
  EXPECT_EQ(a[2], 3);
}

TEST(ArrayTest, InitializingWithExistingArray) {
    int values[5] = {1, 2, 3, 4, 5};
    Array arr(values, 5);
    EXPECT_EQ(arr.size(), 5);
    EXPECT_EQ(arr[0], 1);
    EXPECT_EQ(arr[1], 2);
    EXPECT_EQ(arr[2], 3);
    EXPECT_EQ(arr[3], 4);
    EXPECT_EQ(arr[4], 5);
}

TEST(ArrayTest, CopyConstructor) {
    Array arr1(5);
    Array arr2(arr1);
    EXPECT_EQ(arr1.size(), arr2.size());
}


TEST(ArrayTest, OperatorPlus) {
    int values1[3] = {1, 2, 3};
    int values2[3] = {4, 5, 6};
    Array arr1(values1, 3);
    Array arr2(values2, 3);
    Array result = arr1 + arr2;
    EXPECT_EQ(result[0], 5);
    EXPECT_EQ(result[1], 7);
    EXPECT_EQ(result[2], 9);
}

TEST(ArrayTest, OperatorMinus) {
    int values1[3] = {4, 5, 6};
    int values2[3] = {1, 2, 3};
    Array arr1(values1, 3);
    Array arr2(values2, 3);
    Array result = arr1 - arr2;
    EXPECT_EQ(result[0], 3);
    EXPECT_EQ(result[1], 3);
    EXPECT_EQ(result[2], 3);
}

TEST(ArrayTest, OperatorPlusEquals) {
    int values1[3] = {1, 2, 3};
    int values2[3] = {4, 5, 6};
    Array arr1(values1, 3);
    Array arr2(values2, 3);
    arr1 += arr2;
    EXPECT_EQ(arr1[0], 5);
    EXPECT_EQ(arr1[1], 7);
    EXPECT_EQ(arr1[2], 9);
}

TEST(ArrayTest, OperatorMinusEquals) {
    int values1[3] = {4, 5, 6};
    int values2[3] = {1, 2, 3};
    Array arr1(values1, 3);
    Array arr2(values2, 3);
    arr1 -= arr2;
    EXPECT_EQ(arr1[0], 3);
    EXPECT_EQ(arr1[1], 3);
    EXPECT_EQ(arr1[2], 3);
}

TEST(ArrayTest, OperatorPrefixPlusPlus) {
    int values[3] = {1, 2, 3};
    Array arr(values, 3);
    ++arr;
    EXPECT_EQ(arr[0], 2);
    EXPECT_EQ(arr[1], 3);
    EXPECT_EQ(arr[2], 4);
}

TEST(ArrayTest, OperatorPostfixPlusPlus) {
    int values[3] = {1, 2, 3};
    Array arr(values, 3);
    arr++;
    EXPECT_EQ(arr[0], 2);
    EXPECT_EQ(arr[1], 3);
    EXPECT_EQ(arr[2], 4);
    }


TEST(ArrayTest, OperatorPostfixMinusMinus) {
    int values[3] = {4, 5, 6};
    Array arr(values, 3);
    arr--;
    // the postfix operator returns a copy of the Array before subtracting one from each element
    EXPECT_EQ(arr[0], 3);
    EXPECT_EQ(arr[1], 4);
    EXPECT_EQ(arr[2], 5);
}

TEST(ArrayTest, OperatorEquals) {
    int values[3] = {1, 2, 3};
    Array arr1(values, 3);
    Array arr2 = arr1;
    EXPECT_EQ(arr2[0], 1);
    EXPECT_EQ(arr2[1], 2);
    EXPECT_EQ(arr2[2], 3);
}

TEST(ArrayTest, OperatorEqualEqual) {
    int values1[3] = {1, 2, 3};
    int values2[3] = {1, 2, 3};
    Array arr1(values1, 3);
    Array arr2(values2, 3);
    EXPECT_TRUE(arr1 == arr2);
}

TEST(ArrayTest, OperatorNot) {
    Array arr;
    EXPECT_TRUE(!arr);
    int values[3] = {1, 2, 3};
    Array arr2(values, 3);
    EXPECT_FALSE(!arr2);
}

TEST(ArrayTest, OperatorParentheses) {
    int values[3] = {1, 2, 3};
    Array arr(values, 3);
    EXPECT_EQ(arr(1, 3), -1); // should return -1 because 3 is not at index 1
    EXPECT_EQ(arr(2, 3), 1); // should return 1 and set arr[2] to 0
    EXPECT_EQ(arr[0], 1);
    EXPECT_EQ(arr[1], 2);
    EXPECT_EQ(arr[2], 0);
}

TEST(ArrayTest, InputOperator) {

    Array arr(3);
    std::stringstream ss;
    ss << "1 2 3";
    ss >> arr;
    EXPECT_EQ(arr[0], 1);
    EXPECT_EQ(arr[1], 2);
    EXPECT_EQ(arr[2], 3);
}


int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}


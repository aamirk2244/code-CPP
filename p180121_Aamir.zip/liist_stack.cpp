#include<iostream>
class node{
	public:
		node* priv;
		int val;
		node(int val);
		
};
node::node(int val)
{
	priv = NULL;
	this->val = val;
}
class Stack{
	node *head , *current;
public:
	Stack();
	void push(int val);
	int pop();
	bool is_empty();
};

Stack::Stack()
{
	head = current = NULL;
}
bool Stack::is_empty()
{
	if(head == NULL)
		return true;
	
	return false;
}
void Stack::push(int val)
{
	if(is_empty())
	{
		head = new node(val);
		current = head;
		return;
	}
	node* n= new node(val);
	n->priv = current;
	current  = n;
}
int Stack::pop()
{
	int get;
	node* d;
	if(is_empty())
		throw "Stack Underflow";
		
	if(current == head)
	{
		get = current->val;
		delete head;
		head = NULL;
		current = NULL;
		return get;
	}
	get = current->val;
	d = current;
	current = current->priv;
	delete d;
	d = NULL;
	
	return get;
}
int main()
{
	Stack s;
	try{
			s.push(2);
	
	s.push(20);
	
	s.push(3);	
	std::cout << s.pop() << " ";
		
	std::cout << s.pop()<< " ";
		
	std::cout << s.pop()<< " ";
	
	}catch (const char* msg){
		std::cout << std::endl;std::cout << msg;
	}
	
}

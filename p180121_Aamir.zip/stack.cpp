#include<iostream>
#define size 3
class Stack{
	int *stack;
	int *t;
public:
	void push(int val);
	int pop();
	Stack();
	bool is_empty();
	bool is_full();
};
// 1,2,3
bool Stack::is_empty()
{
	if(t == NULL)
		return true;
		
		
	if(t == stack+size)
	{
		t--;
	}
	return false;
}
bool Stack::is_full()
{
	if(t == NULL)
	{
		t = stack;
	}
	if(t == stack+size)
	{
		return true;
	}
	return false;
}
Stack::Stack()
{
	
	stack= new int[size];
	t = NULL;
}
//1,2,3
void Stack::push(int val)
{
	if(is_full())
		throw "Stack Overflow";
	
	*t = val;
	t++;
	
}
int Stack::pop()
{
	int get;
	if(t==	stack)
	{
		get = *t;
		t = NULL;
		return get;
	
	}
	if(is_empty())
		throw "STack Underflow";
	get = *t;
	t--;
	return get;
}
int main()
{
		Stack s;
	
	try{
	
	
	s.push(23);
	
	s.push(4);
	
	s.push(7);
	
	
	
	std::cout << s.pop() << std::endl;
	std::cout << s.pop() << std::endl;
	std::cout << s.pop() << std::endl;
	
	}catch(const char* msg){
		std::cout << msg << std::endl;
	}
	
}

#include<iostream>
#include<string>
std::string arrange(std::string arr)
{
	for(int i = 0; i < arr.length(); i++ )
	{
		if(arr[i] <= 'A' || arr[i] >= 'Z' )
		{
			arr[i] = arr[i] - 32;
		}
	}
	return arr;	// if small then make it capital letters
}
void palindrome(std::string arr, int indx, int len, int check, int last)
{
	if(len == indx)
		return;
		
	if(check+1 == len)
	{
		std::cout << "Yes The string is Plindrome" << std::endl;
		std::cin.get();
		exit(1);
	}
	if(arr[indx] == arr[last])
		palindrome(arr, indx+1, len, check+1, last-1);
	else
		palindrome(arr, indx+1, len, check, last-1);
}
int main()
{
	// this code will work for small and capital letters as well
	std::string arr  = arrange("MaDam");
	int len = arr.length();
	int last = len-1;
	palindrome(arr, 0, len, 0, last);
	std::cout<< "The string is not palindrome " << std::endl;
}

#include<iostream>


int fact(int f){
	if(f == 1)
		return 1;
	return f * fact(f-1);
}
int main()
{
	std::cout << fact(5);
}

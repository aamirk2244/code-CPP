#include<iostream>
#define SIZE 5
int save_mul;	// global variable

void Prob(int *arr,int len, int indx,  int prod, bool flag, int count)
{
	if(indx == len)
		return;
	if(!flag)
	{
		prod *= arr[indx];
		Prob(arr, len, indx+1, prod, flag, count+1);
		static int save = prod;
		save_mul = save;
		flag = true;
		indx = 0;
	}
	if(count == 0)
	{
		arr[indx]  = save_mul/arr[indx];
		Prob(arr,len, indx+1, save_mul,flag, count  );
		
	}
}
void print(int *arr)
{
	std::cout << "[ ";
	for(int i = 0 ; i < SIZE; i++)
	{
		std::cout << arr[i] << " ";
	}std::cout << " ]";
	std::cout << std::endl;	
}
int main()
{
	int arr[SIZE] = {1,4,1,5,6};
	std::cout << "before Replacing " << std::endl;
	print(arr);
	
	Prob(arr, SIZE,0 ,1, false, 0);
	std::cout << "After Replacing by products " << std::endl;
	print(arr);
	return 0;
}
